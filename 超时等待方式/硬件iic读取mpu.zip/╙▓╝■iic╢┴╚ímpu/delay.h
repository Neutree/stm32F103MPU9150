#ifndef _DELAY__H_
#define _DELAY__H_

void delay_us(u32 nus);
void delay_ms(u16 nms);

#endif

